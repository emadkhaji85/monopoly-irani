# Monopoly Irani · v2

Single-file game (`index.html`). `gameHtml.js` is the same file as an ES string for the React/iframe QA harness (`App.jsx`, `tests.spec.js`).
Serve the folder over http (e.g. `npx serve .`) so `audio/*.mp3` loads.

## What changed in v2
1. **Purchase rule**: one purchase per turn (land, house or factory), only on the tile you landed on that turn. Enforced in `buildHouse/buildFactory` (`G.bought`, `G.landed`, reset in `startTurn`). Buy buttons disable and the dock shows "purchase made".
2. **Board**: 44 tiles, 11 per side, 8 districts × 4 streets, FA + EN names. Board is 980px (`--B`), geometry in `tileRect()`.
3. **Online**: `Net` = PeerJS (WebRTC via the public PeerJS broker, lazy-loaded from unpkg) + BroadcastChannel for same-device tabs; messages are de-duplicated. `Room` is host-authoritative: the host runs the rules and streams snapshots + events (dice, hops, deeds, cards, builds); guests send intents. Disconnected guests are replaced by bots.
   Friend codes `IR-XXXXXX`; requests arrive as actionable toasts (Accept / Decline), offline requests are retried. Deep links: `?friend=IR-…`, `?room=IR-…`. Test two identities in one browser with `?profile=a` / `?profile=b`.
4. **Chat**: HUD button beside Properties, drawer with quick replies, unread badge. Relayed through the host online; table-talk (with bot banter) offline.
5. **Settings**: main menu + in-game (☰ → Settings). Music on/off, SFX on/off, volume, track switcher. Edit `PLAYLIST` to add tracks (`src:null` = built-in generative score).
6. **Language**: Persian (RTL) / English (LTR) toggle in Settings; static text uses `data-en`, dynamic text uses `tr()` / `L()`.

## Known limits
- Trading is local seats + bots only; online guests can't trade yet.
- PeerJS's free broker is fine for friends. For production, run your own PeerServer (`new Peer(id,{host,port,path})` in `Net.connect`).
