import { expect, test } from "@playwright/test";

const frame = (page) => page.locator('iframe[title="مونوپولی ایرانی"]').contentFrame();
const ev = (page, fn, arg) => page.evaluate(fn, arg);
const W = (page, fn, arg) => page.waitForFunction(fn, arg, { timeout: 8500 });
const win = "document.querySelector('iframe').contentWindow";

async function start(page, mode) {
  await page.goto("/");
  await ev(page, (mode) => document.querySelector("iframe").contentWindow.startGame(mode), mode);
  await W(page, () => { const w = document.querySelector("iframe").contentWindow; return w.MD && w.MD.G && w.MD.G.phase === "roll"; });
  return frame(page);
}
const land3 = (page) =>
  ev(page, () => { const w = document.querySelector("iframe").contentWindow; const p = w.MD.G.players[0]; w.moveSteps(p, 3).then(() => w.land(p)); });
// simulate "landed on tile i this turn, nothing bought yet"
const visit = (page, i) => ev(page, (i) => { const G = document.querySelector("iframe").contentWindow.MD.G; G.bought = false; G.landed = i; G.turn = 0; G.phase = "end"; G.busy = false; }, i);

test("loads without browser errors", async ({ page }) => {
  const problems = [];
  page.on("console", (m) => { if (m.type() === "error") problems.push(m.text()); });
  page.on("pageerror", (e) => problems.push(e.message));
  page.on("requestfailed", (r) => problems.push(r.url()));
  await page.goto("/");
  await expect(page.locator("#root > *").first()).toBeAttached();
  expect(problems).toEqual([]);
});

test("v2 board: 44 tiles, 8 districts × 4 streets, bilingual names", async ({ page }) => {
  await start(page, "classic");
  const st = await ev(page, () => {
    const w = document.querySelector("iframe").contentWindow, g = {};
    w.MD.TILES.forEach((t) => { if (t.g) g[t.g] = (g[t.g] || 0) + 1; });
    return { n: w.MD.TILES.length, groups: Object.values(g), named: w.MD.TILES.every((t) => t.name && t.en), dom: w.document.querySelectorAll(".tile").length };
  });
  expect(st).toEqual({ n: 44, groups: [4, 4, 4, 4, 4, 4, 4, 4], named: true, dom: 44 });
});

test("dice roll animates and reports the result", async ({ page }) => {
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  const f = await start(page, "classic");
  await ev(page, () => { document.querySelector("iframe").contentWindow.MD.dice = [2, 1]; });
  await ev(page, () => { document.querySelector("iframe").contentWindow.doRoll(); });
  await expect(f.locator(".dres")).toBeVisible({ timeout: 6000 });
  await expect(f.locator(".dres")).toContainText("۲ + ۱ = ۳");
  expect(errors).toEqual([]);
});

test("classic: landing pops a deed card; buy flow works", async ({ page }) => {
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  const f = await start(page, "classic");
  await land3(page);
  await W(page, () => document.querySelector("iframe").contentWindow.MD.G.phase === "buy");
  const deed = f.locator("#deedOv");
  await expect(deed).toBeVisible();
  await expect(deed).toContainText("نازی‌آباد");
  await expect(deed).toContainText("اجاره · ۴ خانه");
  await expect(deed).not.toContainText("کارخانه");
  await deed.locator('[data-dk="0"]').click();
  await W(page, () => { const G = document.querySelector("iframe").contentWindow.MD.G; return G.props[3].owner === 0 && G.phase === "busy" && G.bought; });
  expect(errors).toEqual([]);
});

test("purchase rule: only one purchase per turn, only on the landed tile", async ({ page }) => {
  await start(page, "classic");
  const st = await ev(page, () => {
    const w = document.querySelector("iframe").contentWindow, G = w.MD.G;
    G.props[3] = { owner: 0, houses: 0, factory: false }; G.props[5] = { owner: 0, houses: 0, factory: false };
    G.phase = "end"; G.bought = false; G.landed = 3;
    const offTile = w.buildHouse(5);          // not landed there
    const first = w.buildHouse(3);            // allowed
    const second = w.buildHouse(3);           // same turn: blocked
    return { offTile, first, second, houses: G.props[3].houses, bought: G.bought };
  });
  expect(st).toEqual({ offTile: false, first: true, second: false, houses: 1, bought: true });
});

test("classic: houses appear as 3D models across visits; factory button stays hidden", async ({ page }) => {
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await start(page, "classic");
  await ev(page, () => { document.querySelector("iframe").contentWindow.MD.G.props[3] = { owner: 0, houses: 0, factory: false }; });
  for (let k = 0; k < 4; k++) { await visit(page, 3); await ev(page, () => document.querySelector("iframe").contentWindow.buildHouse(3)); }
  await W(page, () => document.querySelector("iframe").contentWindow.document.querySelectorAll("#bldLayer .house").length === 4);
  const st = await ev(page, () => { const w = document.querySelector("iframe").contentWindow; return { houses: w.MD.G.props[3].houses, facBtn: !!w.document.querySelector("#plist .b-fac") }; });
  expect(st).toEqual({ houses: 4, facBtn: false });
  expect(errors).toEqual([]);
});

test("industrial: 4 houses convert to a 3D factory on a later visit", async ({ page }) => {
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  const f = await start(page, "ind");
  await expect(f.locator("#modeBadge")).toBeVisible();
  await ev(page, () => { document.querySelector("iframe").contentWindow.MD.G.props[3] = { owner: 0, houses: 0, factory: false }; });
  for (let k = 0; k < 4; k++) { await visit(page, 3); await ev(page, () => document.querySelector("iframe").contentWindow.buildHouse(3)); }
  await visit(page, 3);
  await ev(page, () => document.querySelector("iframe").contentWindow.renderAll());
  const facBtn = f.locator("#plist .b-fac");
  await expect(facBtn).toBeEnabled();
  await facBtn.click();
  await W(page, () => document.querySelector("iframe").contentWindow.document.querySelectorAll("#bldLayer .factory").length === 1);
  const st = await ev(page, () => { const G = document.querySelector("iframe").contentWindow.MD.G; return { factory: G.props[3].factory, houses: G.props[3].houses }; });
  expect(st).toEqual({ factory: true, houses: 0 });
  await ev(page, () => { document.querySelector("iframe").contentWindow.document.querySelector('.tile[data-i="3"]').click(); });
  await expect(f.locator("#tileInfo")).toContainText("درآمد کارخانه هر دور");
  expect(errors).toEqual([]);
});

test("industrial: factory pays automatically after a full lap", async ({ page }) => {
  const f = await start(page, "ind");
  const before = await ev(page, () => {
    const w = document.querySelector("iframe").contentWindow, G = w.MD.G;
    G.props[3] = { owner: 0, houses: 0, factory: true }; w.renderBuildings(3);
    G.players[0].pos = 42; return G.players[0].cash;
  });
  await ev(page, () => { const w = document.querySelector("iframe").contentWindow; w.moveSteps(w.MD.G.players[0], 2); });
  await W(page, (before) => { const G = document.querySelector("iframe").contentWindow.MD.G; return G.players[0].laps === 1 && G.players[0].cash === before + 2000000 + 700000; }, before);
  await expect(f.locator("#log")).toContainText("درآمد صنعتی");
});

test("HUD: chat button sits next to Properties and opens the chat drawer", async ({ page }) => {
  const f = await start(page, "classic");
  const next = await ev(page, () => document.querySelector("iframe").contentWindow.document.querySelector("#bProps").nextElementSibling.id);
  expect(next).toBe("bChat");
  await f.locator("#bChat").click();
  await f.locator("#chatIn").fill("سلام");
  await f.locator("#chatIn").press("Enter");
  await expect(f.locator("#chatList")).toContainText("سلام");
});

test("settings mid-game: language flips to LTR, audio controls present", async ({ page }) => {
  const f = await start(page, "classic");
  await f.locator("#bHome").click();
  await f.locator("#gSettings").click();
  await expect(f.locator("#setDlg .tracks button")).toHaveCount(4);
  await f.locator('#setDlg [data-lang="en"]').click();
  const dir = await ev(page, () => document.querySelector("iframe").contentWindow.document.documentElement.dir);
  expect(dir).toBe("ltr");
  await expect(f.locator("#bChat")).toContainText("Chat");
});
