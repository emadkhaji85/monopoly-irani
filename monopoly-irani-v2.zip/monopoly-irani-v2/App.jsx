// QA harness: renders the single-file Persian Monopoly game in a same-origin iframe
import gameHtml from "./gameHtml.js";

export default function App() {
  return (
    <iframe
      title="مونوپولی ایرانی"
      srcDoc={gameHtml}
      sandbox="allow-scripts allow-same-origin"
      style={{ position: "fixed", inset: 0, width: "100%", height: "100%", border: 0 }}
    />
  );
}
